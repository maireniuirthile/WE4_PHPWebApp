
<?php 

/**********************************************************
* Author: Mary Hurley
*
* Dog.php : this program takes the input from the user in form of radio buttons
* displayed on a html file, instantiates the object DogDB and calls the getAMatch 
* method to find a match. If a match is found in the method a flag is set and an index
* returned to dog.php to display result or report an error message as is appropriate
*
* Assignment: WE4.1 PHP Web App Assignment, Digital Skills Academy
* Student ID: D15128601
* Date : 2016/05/11
* Ref: website link to code referenced or the book, authors name and page number
* http://stackoverflow.com/questions/8416099/php-testing-if-a-radio-button-is-selected-and-get-the-value
* http://stackoverflow.com/questions/1691646/php-echo-text-color
* http://www.w3schools.com/php
***********************************************************/

include ('Dogdb.class.php');
include ('ErrorMsg.class.php');

$displayHeader = true;

function displayMatch($breed, $photo ){
          
        /*  this function outputs the match found in the array of dogs 
  
        */
    
        global $displayHeader;          // using a global to check if I'm irst time in
    
        if ($displayHeader == true){
            $displayHeader = false;        //I only want to display header once
            echo "<h3>The folowing breeds match the criteria  entered :</h3><br/>";
           
        }
        
        /* why doesn't the first echo display the jpg ????? 
           thank you Callum and Brian on the Forum for helping me 
           resolve this it was driving me nuts! 
        echo $breed . " " . '<img src=images/"' .$photo . '">' . "<br/>"; */
        
        echo '<h4><img src="images/' . $photo . '">' . ' ' .  $breed . '<br/></h4>';
      
   
}

if  (isset($_POST["submit"])) {
    if (isset($_POST["dogSize"])) {
        $dogSize  = $_POST["dogSize"];
      //  echo " You are looking for a " . $dogSize  ." dog <br/>";
        echo " You have selected Dog Size " . '<b>' . $dogSize .  '</b>' . "<br/>"; // using some html to pretty up output
    }
    else {
        echo " You have not selected Size! Default of medium will apply.<br/>";
        $dogSize = "medium";
    }
    if (isset($_POST["dogHair"])) {
        $dogHair  = $_POST["dogHair"];
        //echo "with  ". $dogHair . " hair length <br/>";
        echo " You have selected Hair Length  ". '<b>' . $dogHair .  '</b>'. "<br/>";  
    } 
    else {
        echo " You have not selected Hair Length! Default of medium will apply.<br/>";
        $dogHair = "medium";

    }
    if (isset($_POST["dogExercise"])) {
        $dogExercise = $_POST["dogExercise"];
        //echo " whose exercise requirements are " . $dogExercise  ."<br/>";
        echo " You have selected Exercise Needs " . '<b>' . $dogExercise .  '</b>'. "<br/>";

    } 
    else {
        echo " You have not selected Exercise Needs! Default of medium will apply.<br/>";
        $dogExercise = "medium";
    }
    
    $dog = new DogDb();          // this Class contains my database of dogs
    $error = new ErrorMsg();     // this Class is for reporting error messages 
   
    $dogCount = $dog->dogsArrayLen();
    $indexHolder = 0;           
    $dogIndex = 0;

    /*  I need to loop thru my array of dogs and find a match 
        when I find a match I call displayMatch to output the find
        then I move indexHolder 1 beyound to where the match is found to see if 
        there is any other matches in the array to display. This loop will
        terminates when the getAMatch method returns -1 to dogIndex which will 
        mean we are at the end of our array. getMatchFound method will let us know if
        a match was found in our array or not
    */
    
    while ( $dogIndex >= 0) {
        $dogIndex = $dog->getAMatch($dogSize, $dogHair, $dogExercise, $indexHolder);
        if ($dogIndex >= 0 ){
            displayMatch($dog->getIndexedDogBreed($dogIndex), $dog->getIndexedDogPhoto($dogIndex) );
            $indexHolder = $dogIndex + 1;
        }
    }

    if ($dog->getMatchFound() == false ){
        $error->setErrMsg("No match found for criteria entered!");
    }    
}
else { 
        $error->setErrMsg("Please submit the form.");
}

?>