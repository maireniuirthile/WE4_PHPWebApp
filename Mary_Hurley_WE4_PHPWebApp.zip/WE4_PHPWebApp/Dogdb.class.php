<?php 

/**********************************************************
* Author: Mary Hurley
*
* The Class DogDB contains the hardcoded data for the  WE4.1 PHP Web App assignment.
* The data is stored in a private array of dogs, where each elements is of Dog Class and
* so the Dog.class.php file is included. The constructor populates the array.
* 
* The methods of this Class are :
*
*           public getIndexedDogBreed($index)
*           public function getIndexedDogBreed($index)
*           public function getIndexedDogPhoto($index)
*           public function dogsArrayLen()
*           public function getMatchFound()
*           public function setMatchFound($flag)
*           public function getAMatch($dogSize, $dogHair, $dogExercise)
*
*   details of what each method does is included below.
*
* Assignment: WE4.1 PHP Web App Assignment, Digital Skills Academy
* Student ID: D15128601
* Date : 2016/05/11
* Ref: website link to code referenced or the book, authors name and page number
* http://stackoverflow.com/questions/19215074/store-images-in-array-php
* http://www.webdeveloper.com/forum/showthread.php?142829-display-an-array-of-images-using-php
***********************************************************/

include ('Dog.class.php');


class Dogdb {
            
    private $dogs = array();
    private $matchFound;
    
    public function __construct(){
        
        /* instantiating Dog class from Dogdb class */
        
        /* this is my dog database */
        
        $this->dogs[0] = new Dog("Akita","large","long", "high", "akita_s.jpg");
        $this->dogs[1] = new Dog("Harrier","medium","short","high", "harrier_s.jpg");
        $this->dogs[2] = new Dog("Beagle","small","medium", "high", "beagle_s.jpg");
        $this->dogs[3] = new Dog("Boxer","medium","short","high", "boxer_s.jpg" );
        $this->dogs[4] = new Dog("Basset Hound","medium","medium","medium", "basset_hound_s.jpg" );
        $this->dogs[5] = new Dog("Dalmatian","large","medium","high", "dalmatian_s.jpg" );
        $this->dogs[6] = new Dog("German Shepherd","large","medium","high", "german_shepherd_dog_s.jpg");
        $this->dogs[7] = new Dog("Great Dane","large","medium","moderate", "great_dane_s.jpg");
        $this->dogs[8] = new Dog("Newfoundland","large","long","moderate", "newfoundland_dog_s.jpg");
        $this->dogs[9] = new Dog("Bearded Collie","large","long","high", "bearded_collie_s.jpg");
        $this->dogs[10] = new Dog("Affenpinscher","small","medium","high", "affenpinscher_s.jpg"); 
        $this->dogs[11] = new Dog("Bedlington Terrier","medium","medium","medium", "bedlington_terrier_s.jpg"); 
        $this->dogs[12] = new Dog("Doberman","large","medium","high", "doberman_pinscher_s.jpg"); 
        $this->dogs[13] = new Dog("Greyhound","large","short","high", "greyhound_s.jpg"); 
        $this->dogs[14] = new Dog("Chihuahua","small","short","low", "chihuahua_s.jpg"); 
        $this->dogs[15] = new Dog("Pointer","large","medium","high", "pointer_s.jpg"); 
        $this->dogs[16] = new Dog("French Bulldog","small","short","low", "french_bulldog_s.jpg"); 
        $this->dogs[17] = new Dog("Chow Chow","medium","long","low", "chow_chow_s.jpg"); 
        
        $this->matchFound = false;
    }
    
    
    public function getIndexedDogBreed($index){
        /* returns the DogBreed at the specified index */
        
        return($this->dogs[$index]->getDogBreed());
    }

    public function getIndexedDogPhoto($index){
        /* returns the DogPhoto at the specified index */

        return($this->dogs[$index]->getDogPhoto());
    }
    
    public function dogsArrayLen(){
        /* returns the length of the array dogs */
        return(count($this->dogs));
    }

    
    public function getMatchFound(){
        /* returns the matchFound flag */

        return($this->matchFound);
    }

    public function setMatchFound($flag){
        /* set the matchFound flag to value of flag passed in*/

        $this->matchFound = $flag;
    }

    public function getAMatch($dogSize, $dogHair, $dogExercise, $startPos){
        
        /*  this function takes as parameters user stored input and an indexholder to
            remember location a match was found when parsing the array.
            The function will return an index to a match found or -1 if no
            match found and end of array reached.
        */
                
        for ($i=$startPos; $i < $this->dogsArrayLen(); $i++){
            
            if ( ($this->dogs[$i]->getDogSize() == $dogSize) &&
                 ($this->dogs[$i]->getDogHair() == $dogHair) &&
                 ($this->dogs[$i]->getDogExercise() == $dogExercise) ){
            
                    $this->setMatchFound(true);         // match found so flag it for later
                    return ($i);                        // return an index to the match
                }
            
             if (($i + 1) == $this->dogsArrayLen()){      
               return(-1);
            }
        }
        return(-1);  
        }
    }
?>