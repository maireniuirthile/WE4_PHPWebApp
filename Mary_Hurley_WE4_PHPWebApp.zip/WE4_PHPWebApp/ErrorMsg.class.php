
<?php 

/**********************************************************
* Author: Mary Hurley
*
* This is a class created for error messages. Instead of using an 
* echo to display the message to user I am going to use an alert
* box using javascript.
*
* Assignment: WE4.1 PHP Web App Assignment, Digital Skills Academy
* Student ID: D15128601
* Date : 2016/05/18
* Ref: website link to code referenced or the book, authors name and page number
*      http://stackoverflow.com/questions/3556381/how-to-add-script-inside-a-php-code
*      http://stackoverflow.com/questions/10596218/how-to-write-javascript-code-inside-php
***********************************************************/

    class ErrorMsg {
        
        private $errMsg;

        // constructor
        
        public function __construct() {
            
            $this->errMsg = "";
        }
        
        // methods
                
        public function getErrMsg(){
            return ($this->errMsg);
        }
        
        public function setErrMsg($msg){
           // echo $this->errMsg = $msg;  going to use an alert box instead 
            echo "<script type=\"text/javascript\">
                    alert ('$msg');
                  </script>";
        }
    }

?>
       
