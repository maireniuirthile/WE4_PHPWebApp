
<?php 

/**********************************************************
* Author: Mary Hurley
*
* The Dog Class is the class that holds all the information 
* that I want to store about Dog. It has all the getters that 
* need to access my data. I am not  
* using the setters for this assignment but I included one below  
*
* Assignment: WE4.1 PHP Web App Assignment, Digital Skills Academy
* Student ID: D15128601
* Date : 2016/05/11
* Ref: website link to code referenced or the book, authors name and page number
* http://www.w3schools.com/php
***********************************************************/

    class Dog {
        
        private $dogBreed;
        private $dogSize;
        private $dogHair;
        private $dogExercise;
        private $photo;

        // constructor
        
        public function __construct($breed, $size, $hair, $exercise, $pic) {
            
            $this->dogBreed = $breed;
            $this->dogSize = $size;
            $this->dogHair = $hair;
            $this->dogExercise = $exercise;
            $this->dogPic = $pic;
        }
        
        
        //getters
        
        
        public function getDogBreed(){
            return ($this->dogBreed);
        }

        public function getDogSize(){
            return ($this->dogSize);
        }

        public function getDogHair(){
            return ($this->dogHair);
        }
        
        public function getDogExercise(){
            return ($this->dogExercise);
        }
        public function getDogPhoto(){
            return ($this->dogPic);
        }
        
        //setters
        public function setDogBreed($breed){
            $this->dogBreed = $breed;
        }
        
    }

?>
       
